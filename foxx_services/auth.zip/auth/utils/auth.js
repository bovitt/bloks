"use strict";

const createAuth = require("@arangodb/foxx/auth");

const auth = createAuth();
module.exports = auth;
